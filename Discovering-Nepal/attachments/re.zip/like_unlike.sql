-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 19, 2023 at 09:26 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `discovering-nepal`
--

-- --------------------------------------------------------

--
-- Table structure for table `like_unlike`
--

CREATE TABLE `like_unlike` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `postid` int(11) NOT NULL,
  `type` int(2) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `like_unlike`
--

INSERT INTO `like_unlike` (`id`, `userid`, `postid`, `type`, `timestamp`) VALUES
(2, 5, 5, 1, '2023-06-15 15:24:57'),
(3, 5, 6, 1, '2023-06-15 15:23:15'),
(4, 5, 7, 1, '2023-06-15 15:23:48'),
(5, 4, 6, 1, '2023-06-15 16:35:14'),
(6, 4, 5, 0, '2023-06-15 16:36:30'),
(7, 40, 5, 0, '2023-07-18 05:29:49'),
(8, 40, 6, 1, '2023-07-18 05:29:01'),
(9, 40, 8, 1, '2023-07-18 05:30:04'),
(10, 40, 7, 1, '2023-07-18 05:28:29'),
(11, 111, 6, 1, '2023-07-18 05:33:57'),
(12, 111, 5, 1, '2023-07-18 05:34:01'),
(13, 111, 7, 1, '2023-07-18 05:34:03'),
(14, 112, 6, 1, '2023-07-18 06:14:06'),
(15, 112, 5, 1, '2023-07-18 06:08:30'),
(16, 112, 7, 1, '2023-07-18 05:58:06'),
(17, 112, 8, 1, '2023-07-18 06:02:30'),
(18, 212, 6, 0, '2023-07-18 06:43:00'),
(19, 212, 7, 0, '2023-07-19 07:12:35'),
(20, 212, 0, 1, '2023-07-18 07:09:04');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `like_unlike`
--
ALTER TABLE `like_unlike`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `like_unlike`
--
ALTER TABLE `like_unlike`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
