-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 19, 2023 at 09:26 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `discovering-nepal`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_comment`
--

CREATE TABLE `tbl_comment` (
  `comment_id` int(11) NOT NULL,
  `parent_comment_id` int(11) NOT NULL,
  `comment` varchar(200) NOT NULL,
  `comment_sender_name` varchar(40) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_comment`
--

INSERT INTO `tbl_comment` (`comment_id`, `parent_comment_id`, `comment`, `comment_sender_name`, `date`) VALUES
(9, 0, 'hello', 'Ram', '2023-06-09 13:37:51'),
(10, 9, 'hihihihi', 'sita', '2023-06-09 13:43:10'),
(11, 0, 'gfdgd', 'hello', '2023-06-10 06:31:39'),
(12, 0, 'hello its me\r\n', 'aashutosh bista', '2023-06-13 12:55:25'),
(13, 0, 'btete', 'Ram', '2023-07-12 09:13:47'),
(14, 13, 'dsfsfdfds', 'dffd', '2023-07-12 09:14:00'),
(15, 14, 'hjfjhg', 'hghj', '2023-07-12 09:16:12'),
(16, 14, 'fg', 'fin', '2023-07-12 09:16:48'),
(17, 0, 'new one\r\n', 'aashutosh bista', '2023-07-15 06:51:39'),
(18, 17, 'newww', 'aashutosh bista', '2023-07-15 06:52:05'),
(19, 10, 'on sita', 'aashutosh bista', '2023-07-15 06:54:20'),
(20, 19, 'okay okay', 'aashutosh bista', '2023-07-15 10:24:04'),
(21, 16, 'helloooooo', 'aashutosh bista', '2023-07-15 10:55:31'),
(22, 20, 'okay okay', 'aashutosh bista', '2023-07-15 12:13:13'),
(23, 10, 'mymy', 'aashutosh bista', '2023-07-15 12:23:52'),
(24, 0, 'mymy', 'aashutosh bista', '2023-07-18 13:19:25');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_comment`
--
ALTER TABLE `tbl_comment`
  ADD PRIMARY KEY (`comment_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_comment`
--
ALTER TABLE `tbl_comment`
  MODIFY `comment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
